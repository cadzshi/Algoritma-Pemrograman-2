#include "header.h"

int main()
{
    int x, y;
    scanf ("%d %d", &x, &y);
    int hasil = power(x, y);

    printf("%d\n", hasil);
}