#include <stdio.h>

int power(int x, int y);