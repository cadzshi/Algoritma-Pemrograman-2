#include "header.h"

int main()
{
    rekursifAlphabet('Z');
}