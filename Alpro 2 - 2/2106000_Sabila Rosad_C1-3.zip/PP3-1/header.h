#include <stdio.h>

void rekursifAlphabet (char alphabet);
