#include <stdio.h>

void rekursif(int a, int b);