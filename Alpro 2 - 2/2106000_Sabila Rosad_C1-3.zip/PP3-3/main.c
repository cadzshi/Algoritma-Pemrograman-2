#include "header.h"

int main()
{
    int x, y;
    scanf("%d %d", &x, &y);

    rekursif(x, y);
    return 0;
}