#include <string.h>
#include <stdio.h>

void selection(int n, char nama[][50]);
void insertion(int n, char nama[][50]);
void printsorting(int n, char nama[][50], char metode[50]);
