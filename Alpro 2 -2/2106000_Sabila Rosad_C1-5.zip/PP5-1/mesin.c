#include "header.h"

//prosedur bubblesort
void bubblesort (int n, data angka[])
{
    int swap, temp, i, j;
    do
    {
        swap = 0; 
        for (i = 0; i < n - 1; i++)
        { 
            for (j = 0; j < n - i - 1; j++)
            {
                if ((angka[j].pembilang * angka[j + 1].penyebut) > (angka[j + 1].pembilang * angka[j].penyebut))
                { 
                    temp = angka[j].pembilang;
                    angka[j].pembilang = angka[j+1].pembilang;
                    angka[j+1].pembilang = temp;

                    temp = angka[j].penyebut;
                    angka[j].penyebut = angka[j+1].penyebut;
                    angka[j+1].penyebut = temp;
                    swap = 1;
                }
            }
            
            
        }
    } while (swap  == 1);
}
//quicksort masih salah bang :'''''''''
void quicksort (data angka[], int kiri, int kanan)
{
    int i, j, temp, pivot;
    i = kiri, j = kanan;
    pivot = angka[(kanan + kiri) / 2].pembilang;
    do
    {
        while ((angka[i].pembilang < pivot) && (i <= j))
        {
            i++;
        }
        while ((angka[j].penyebut > pivot) && (i <= j))
        {
            j--;
        }
        if (i < j)
        {
            temp = angka[i].pembilang;
            angka[i].pembilang = angka[j].penyebut;
            angka[j].penyebut = temp;
            i++;
            j--;
        }


    } while (i < j);
    if (kiri < j && j < kanan)
    {
        quicksort(angka, kiri, j);
    }
    if (i < kanan && i > kiri)
    {
        quicksort(angka, i, kanan);
    }
}

//print hasil
void printhasil (int n, data angka[])
{
    for (int i = 0; i < n; i++)
        {
            printf("%d ", angka[i].pembilang);
        }
        printf("\n");
        for (int i = 0; i < n; i++)
        {
            printf("- ");
        }
        printf("\n");
        for (int i = 0; i < n; i++)
        {
            printf("%d ", angka[i].penyebut);
        }
}