#include <stdio.h>
#include <string.h>

void search(int n, int num[], int target);

