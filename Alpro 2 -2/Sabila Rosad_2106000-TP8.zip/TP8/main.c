#include "head.h"

int main()
{
    init(); 

    system("cls");
    return 0;
}