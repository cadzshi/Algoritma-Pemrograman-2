#include "head.h"

int main()
{
    scanf("%d %d", &n, &m);
    mahasiswa data[n][m];
    
    scan (data);
    tukarnilai (data);
    print (data);
   
    return 0;
}