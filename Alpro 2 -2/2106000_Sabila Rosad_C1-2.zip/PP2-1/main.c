#include "head.h"

int main()
{
    scanf("%d %d", &n, &m);
    data warna[n][m];

    
    scanwarna (warna);
    printwarna (warna);
    pembatas();
    
    
    
    return 0;
}